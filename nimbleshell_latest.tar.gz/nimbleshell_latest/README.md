# nimbleshell-cli
Welcome to NimbleEdge Command Line. This helps you to interact with NimbleEdge systems and update your Inference models in NimbleEdge Cloud.

Warning: Path of NimbleEdge CLI is not added to your shell PATH. Add NimbleEdge CLI path in your shell to keep on using it. 

To do so , run echo $PATH=$HOME/.nimbleshell:$PATH >> $HOME/.bashrc or echo $PATH=$HOME/.nimbleshell:$PATH' >> $HOME/.zshrc  depending on which shell you use.

For usage details, run  nimbleshell -h